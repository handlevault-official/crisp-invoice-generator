import io, os, datetime
from flask import Flask, request, send_file, render_template_string, abort
from invoice import build_invoice, num

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024

PAGE = r"""<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>InvoiceSov</title>
<style>:root{color-scheme:light dark}*{box-sizing:border-box}body{font:15px system-ui;max-width:820px;margin:30px auto;padding:0 14px}
h1{margin-bottom:0}fieldset{margin:14px 0;border:1px solid #8884;border-radius:10px;padding:12px}legend{font-weight:700;padding:0 6px}
label{display:block;font-weight:600;font-size:13px;margin:8px 0 3px}input,select,textarea,button{width:100%;padding:8px;font:inherit}
textarea{min-height:64px}.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
.row{display:grid;grid-template-columns:3fr 70px 100px 100px 34px;gap:6px;margin:6px 0;align-items:center}
.row .amt{text-align:right;font-variant-numeric:tabular-nums}button{cursor:pointer;font-weight:700}
.sec{width:auto;padding:6px 12px;font-weight:600}#tot{text-align:right;font-size:17px;margin-top:10px;line-height:1.6}small{opacity:.7}</style>
<h1>🧾 InvoiceSov</h1>
<small>Create professional PDF invoices. Runs on your own server: no accounts, no tracking, nothing stored. Your business details are remembered only in this browser.</small>
<form id=f method=post action=/generate enctype=multipart/form-data>
<fieldset><legend>Your business</legend><div class=g>
<div><label>Business name</label><input name=biz_name id=biz_name required></div>
<div><label>Logo (optional)</label><input type=file name=logo accept="image/*"></div>
<div><label>Accent color</label><input type=color name=accent id=accent value="#2563eb"></div></div>
<label>Address / contact / tax ID</label><textarea name=biz_info id=biz_info></textarea></fieldset>
<fieldset><legend>Client</legend><label>Client name</label><input name=client_name required>
<label>Client address / contact</label><textarea name=client_info></textarea></fieldset>
<fieldset><legend>Invoice</legend><div class=g>
<div><label>Invoice #</label><input name=number id=number value="INV-0001"></div>
<div><label>Issue date</label><input type=date name=issue value="{{today}}"></div>
<div><label>Due date</label><input type=date name=due_date value="{{due}}"></div>
<div><label>Currency</label><select name=currency id=currency><option>PHP<option>USD<option>EUR<option>GBP<option>AUD<option>CAD<option>SGD<option>JPY<option>INR<option>AED</select></div></div></fieldset>
<fieldset><legend>Items</legend><div id=items></div><button type=button class=sec onclick="add()">+ Add item</button></fieldset>
<fieldset><legend>Totals</legend><div class=g>
<div><label>Discount %</label><input type=number step=any name=discount id=discount value=0 min=0 max=100></div>
<div><label>Tax %</label><input type=number step=any name=tax id=tax value=0 min=0></div>
<div><label>Tax name</label><input name=tax_label id=tax_label value="Tax"></div>
<div><label>Shipping / fees</label><input type=number step=any name=shipping value=0></div>
<div><label>Amount already paid</label><input type=number step=any name=paid value=0></div></div>
<div id=tot></div></fieldset>
<fieldset><legend>Extras</legend><label>Payment details (bank, GCash, PayPal...)</label><textarea name=payment id=payment></textarea>
<label>Notes / terms</label><textarea name=notes id=notes>Thank you for your business.</textarea></fieldset>
<button>Download PDF invoice</button></form>
<script>
const $=id=>document.getElementById(id),keep=['biz_name','biz_info','accent','currency','payment','notes','tax_label','tax'];
try{keep.forEach(k=>{const v=localStorage.getItem('isov_'+k);if(v!==null)$(k).value=v});
const n=localStorage.getItem('isov_next');if(n)$('number').value=n}catch(e){}
function add(d='',q=1,r=''){const e=document.createElement('div');e.className='row';
e.innerHTML=`<input name=desc placeholder="Description" value="${d}"><input name=qty type=number step=any value=${q}>
<input name=rate type=number step=any placeholder="Rate" value="${r}"><div class=amt>0.00</div><button type=button class=sec onclick="this.parentNode.remove();calc()">×</button>`;
e.oninput=calc;$('items').appendChild(e);}
function calc(){let s=0;document.querySelectorAll('.row').forEach(r=>{const[q,rt]=[r.children[1].value,r.children[2].value].map(Number);
const a=(q||0)*(rt||0);s+=a;r.children[3].textContent=a.toFixed(2)});
const d=s*(+$('discount').value||0)/100,t=(s-d)*(+$('tax').value||0)/100,sh=+f.shipping.value||0,tot=s-d+t+sh,pd=+f.paid.value||0,c=$('currency').value;
$('tot').innerHTML=`Subtotal: ${c} ${s.toFixed(2)}<br>Total: <b>${c} ${tot.toFixed(2)}</b><br>Balance due: <b>${c} ${(tot-pd).toFixed(2)}</b>`}
document.querySelectorAll('#f input,#f select').forEach(e=>e.addEventListener('input',calc));
$('f').addEventListener('submit',()=>{try{keep.forEach(k=>localStorage.setItem('isov_'+k,$(k).value));
const m=$('number').value.match(/^(.*?)(\d+)$/);if(m)localStorage.setItem('isov_next',m[1]+String(+m[2]+1).padStart(m[2].length,'0'))}catch(e){}});
add();calc();
</script>"""

@app.get("/")
def home():
    t = datetime.date.today()
    return render_template_string(PAGE, today=t, due=t + datetime.timedelta(days=14))

@app.post("/generate")
def generate():
    f = request.form
    descs, qtys, rates = f.getlist("desc"), f.getlist("qty"), f.getlist("rate")
    items = [dict(desc=d, qty=num(q, 1), rate=num(r)) for d, q, r in zip(descs, qtys, rates) if d.strip() or num(r)]
    if not items: abort(400, "Add at least one item")
    g = lambda k, dflt="": (f.get(k) or dflt).strip()
    accent = g("accent", "#2563eb")
    if not (len(accent) == 7 and accent.startswith("#")): accent = "#2563eb"
    data = dict(biz_name=g("biz_name", "Your Business")[:80], biz_info=g("biz_info")[:400], client_name=g("client_name")[:80],
                client_info=g("client_info")[:400], number=g("number", "INV-0001")[:30], issue=g("issue"), due_date=g("due_date"),
                currency=g("currency", "PHP")[:4], accent=accent, items=items, tax_label=g("tax_label", "Tax")[:20],
                discount=min(100, max(0, num(f.get("discount")))), tax=max(0, num(f.get("tax"))),
                shipping=num(f.get("shipping")), paid=num(f.get("paid")), payment=g("payment")[:600], notes=g("notes")[:800])
    logo = request.files["logo"].read() if "logo" in request.files and request.files["logo"].filename else None
    try:
        pdf = build_invoice(data, logo)
    except Exception as e:
        abort(400, f"Could not build invoice: {e}")
    return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True,
                     download_name=f"{data['number']}.pdf")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
